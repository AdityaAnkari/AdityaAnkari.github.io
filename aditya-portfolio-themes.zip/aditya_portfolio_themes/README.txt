# GitHub Pages Portfolio Themes

This package contains two ready-to-upload portfolio themes:

- `dark-theme/`
- `light-theme/`

## How to use on GitHub Pages
1. Create a public repository named `yourusername.github.io`
2. Upload the contents of one theme folder to the repository root
3. Commit the files
4. In GitHub repo settings, open **Pages**
5. Set source to **Deploy from branch** and choose `main`

Your site will be live at:
`https://yourusername.github.io`
